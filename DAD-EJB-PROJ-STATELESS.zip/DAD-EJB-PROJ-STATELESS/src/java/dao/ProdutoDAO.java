/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;




import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;
import model.Produto;



public class ProdutoDAO {
    private EntityManager em;
    
    public ProdutoDAO(EntityManager em){
        this.em = em;
    }
    
    public void inserir(Produto produto){
        this.em.persist(produto);
    }
    
    public void remover(Produto produto){
        produto = this.em.find(Produto.class, produto.getIdProduto());
        this.em.remove(produto);
    }
    
    
    public List<Produto> listar(){
        Query query = this.em.createNamedQuery("Produto.FindAll", Produto.class);
        return (List<Produto>)query.getResultList();
    }
    
  
    
    
}
