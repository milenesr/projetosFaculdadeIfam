/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
//import model.Categoria;
import model.Produto;

/**
 *
 * @author milen
 */
/*public class CategoriaDAO {
    private EntityManager em;
    
    public CategoriaDAO(EntityManager em){
        this.em = em;
    }
    
    public void inserir(Categoria categoria){
        this.em.persist(categoria);
    }
     public List<Categoria> listar(){
        Query query = this.em.createNamedQuery("Categoria.FindAll", Categoria.class);
        return (List<Categoria>)query.getResultList();
    }
}
*/
