/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

//import dao.CategoriaDAO;
import java.util.List;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
//import model.Categoria;
//import remote.ICategoriaService;

/**
 *
 * @author milen
 */
//@Stateless
//@Remote(ICategoriaService.class)
/*public class CategoriaService implements ICategoriaService{
    private CategoriaDAO categoriaDAO;
    
    @PersistenceContext
    private EntityManager em;
    
    
    @Override
    public void inserir(Categoria categoria) {
        categoriaDAO = new CategoriaDAO(this.em);
        categoriaDAO.inserir(categoria);
    }

    @Override
    public List<Categoria> listar() {
        categoriaDAO = new CategoriaDAO(this.em);
        return categoriaDAO.listar();
    }
    
}
*/