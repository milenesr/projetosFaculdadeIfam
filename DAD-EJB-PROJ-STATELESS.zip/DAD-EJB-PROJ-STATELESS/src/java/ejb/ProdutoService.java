/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dao.ProdutoDAO;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.Produto;
import remote.IProdutoService;

/**
 *
 * @author Antonio
 */
@Stateless
@Remote(IProdutoService.class)
public class ProdutoService implements IProdutoService{
    private ProdutoDAO produtoDAO;
    
    @PersistenceContext
    private EntityManager em;
    
    @Override
    public void inserir(Produto produto) {
        produtoDAO = new ProdutoDAO(this.em);
        produtoDAO.inserir(produto);
    }

    @Override
    public void remover(Produto produto) {
        produtoDAO = new ProdutoDAO(this.em);
        produtoDAO.remover(produto);
    }

    @Override
    public List<Produto> listar() {
        produtoDAO = new ProdutoDAO(this.em);
        return produtoDAO.listar();
    }
    
}
