package gerenciaproduto;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.Produto;

/**
 *
 * @author THAIS
 */
public class TabelaProdutoModelo extends AbstractTableModel{
    
    private final List<Produto> produtos;
   // private final List<Categoria> categorias;
    public TabelaProdutoModelo(List<Produto> produtos) {
        this.produtos = produtos;
       // this.categorias = categorias;
    }

    @Override
    public int getRowCount() {
        return produtos.size();
        //return categorias.size();
    }

    @Override
    public int getColumnCount() {
       return 3;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Produto produto = produtos.get(rowIndex);
       // Categoria categoria = categorias.get(rowIndex);
        switch(columnIndex){
            case 0: return produto.getCodigo();
            case 1: return produto.getNome();
            case 2: return produto.getValor();
         //   case 3: return categoria.getNome();
            default: return "";
        }
    }
    
    
    public String getColumnName(int column){
        switch(column){
            case 0: return "Código";
            case 1: return "Nome";
            case 2: return "Valor";
           // case 3: return "Categoria";
            default: return "";
        }
    }
}
