/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import javax.persistence.EntityManager;
import model.Cliente;
import model.Compra;
import model.Item;
import model.Produto;

/**
 *
 * @author Antonio
 */
public class CompraDAO {
    
    private EntityManager em;
    
    public CompraDAO(EntityManager em){
        this.em = em;
    }
    
    public void finalizarCompra(Compra compra){
       
       
        
        ItemDAO itemDAO = new ItemDAO(this.em); 
        ClienteDAO cliDAO = new ClienteDAO(this.em);
        for(Item item: compra.getItens()){
            item.setProduto(em.find(Produto.class, item.getProduto().getIdProduto()));
            compra.setCliente(em.find(Cliente.class, item.getProduto().getIdProduto()));
        }
        for(Item it: compra.getItens()){
            itemDAO.inserir(it);
        }
        this.em.persist(compra);  
    }
    
}
