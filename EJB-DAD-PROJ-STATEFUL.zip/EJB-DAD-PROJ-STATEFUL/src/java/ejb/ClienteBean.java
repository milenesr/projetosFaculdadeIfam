/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dao.ClienteDAO;
import java.util.List;
import javax.ejb.Remote;
import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.Cliente;
import model.Produto;
import remote.ICarrinhoBean;
import remote.IClienteBean;

/**
 *
 * @author milen
 */

@Stateful
@Remote(IClienteBean.class)
public class ClienteBean {
    private ClienteDAO clienteDAO;
    
    @PersistenceContext
    private EntityManager em;
    
     
    public void inserir(Cliente cliente) {
        clienteDAO = new ClienteDAO(this.em);
        clienteDAO.inserir(cliente);
    }
    
    public List<Cliente> listarCliente() {
       clienteDAO = new ClienteDAO(this.em);
        return clienteDAO.listar();
    }
    
    
}
