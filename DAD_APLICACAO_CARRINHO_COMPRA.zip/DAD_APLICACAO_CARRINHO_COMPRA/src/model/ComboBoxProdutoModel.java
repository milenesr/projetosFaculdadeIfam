/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;

/**
 *
 * @author Antonio
 */
public class ComboBoxProdutoModel extends AbstractListModel<Object> implements ComboBoxModel<Object>{
    private final List<Produto> produtos;
    private Produto produto;

    public ComboBoxProdutoModel(List<Produto> produtos) {
        this.produtos = produtos;
    }
    
    @Override
    public int getSize() {
        return this.produtos.size();
    }

    @Override
    public Object getElementAt(int index) {
        Produto produtoSelecionado = this.produtos.get(index);
        return produtoSelecionado;
    }

    @Override
    public void setSelectedItem(Object anItem) {
        for(Produto produto: this.produtos){
            if(produto.getNome().equals(anItem.toString())){
                this.produto = (Produto) produto;
            }
        }
        
    }

    @Override
    public Object getSelectedItem() {
        return this.produto;
    }
    
}
