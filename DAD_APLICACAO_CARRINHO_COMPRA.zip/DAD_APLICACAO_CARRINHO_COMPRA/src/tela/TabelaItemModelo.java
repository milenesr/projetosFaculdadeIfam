/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tela;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.Cliente;
import model.Compra;
import model.Item;



/**
 *
 * @author milen
 */
public class TabelaItemModelo extends AbstractTableModel {
    private List<Item> listaItens;    
    private List<Cliente>listCliente;
    //private Compra compra;
    
    private DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

    public TabelaItemModelo(List<Item> listItens,List<Cliente> listCliente) {
        this.listaItens = listItens;
        this.listCliente = listCliente;
        
    }
    
    @Override
    public int getRowCount() {
        return listaItens.size();
    }

    @Override
    public int getColumnCount() {
         return 6;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
      
        Item item = listaItens.get(rowIndex); 
        Cliente cliente = listCliente.get(rowIndex);
        
        
        //Date date = compra.getDataCompra().getTime();
        switch(columnIndex) {
            case 0: return item.getProduto().getCodigo();
            case 1: return item.getProduto().getNome();
            case 2: return item.getProduto().getValor();
            case 3: return item.getQuantidade();
            case 4: return item.getTotalItem();
            case 5: return cliente.getNome();
            //case 6: return cliente.getCpf();
            default: return "";
        }
    }

    @Override
    public String getColumnName(int column) {
        switch(column){
            case 0: return "Código do Produto";
            case 1: return "Produto";
            case 2: return "Valor";
            case 3: return "Quantidade";
            case 4: return "Total do Item";
            case 5: return "Nome do Cliente";
           // case 6: return "Cpf";
            default : return "";
             
        }
    }
    
    
}
